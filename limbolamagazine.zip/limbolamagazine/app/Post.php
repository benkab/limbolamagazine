<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{

    protected $fillable = ['cover', 'title', 'slug', 'body', 'status', 'user_id', 'published_at', 'category_id'];

    public function user()
    {
        return $this->belongsTo('App\User');
    }

    public function tags()
    {
        return $this->belongsToMany('App\Tag');
    }

    public function images()
    {
        return $this->belongsToMany('App\Image');
    }

    public function likes()
    {
        return $this->hasMany('App\Like');
    }

    public function categories()
    {
        return $this->hasOne('App\Category', 'id');
    }
    
}
