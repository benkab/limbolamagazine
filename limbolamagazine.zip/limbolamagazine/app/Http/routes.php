<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::group(['middleware' => ['web']], function () {
    // routes here
});

// Index
Route::get('/', [
	'uses' => 'LimbolaController@getLimbola'
]);

// Tasks
	Route::get('/limbola/admin/tasks', [
		'uses' => 'TaskController@getTasks',
		'as'   => 'view_tasks',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> ['Administrateur', 'Redacteur']
	]);

	Route::post('/limbola/admin/tasks', [
		'uses' => 'TaskController@postTask',
		'as'   => 'post_task',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> ['Administrateur', 'Redacteur']
	]);

	

// Comments
	Route::get('/limbola/admin/comments', [
		'uses' => 'CommentController@getComments',
		'as'   => 'view_comments',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> ['Administrateur', 'Redacteur']
	]);

// Visitors
	Route::get('/limbola/admin/visitors', [
		'uses' => 'UserController@getVisitors',
		'as'   => 'view_visitors',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> 'Administrateur'
	]);

	Route::get('/limbola/admin/visitor/block/{id}', [
		'uses' => 'UserController@blockUser',
		'as'   => 'block',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> 'Administrateur'
	]);

	Route::get('/limbola/admin/visitor/unblock/{id}', [
		'uses' => 'UserController@unblockUser',
		'as'   => 'unblock',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> 'Administrateur'
	]);

// Posts
	Route::get('/limbola/admin/posts', [
		'uses' => 'PostController@getPosts',
		'as'   => 'view_posts',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> ['Administrateur', 'Redacteur']
	]);

	Route::get('/limbola/admin/posts/create', [
		'uses' => 'PostController@getPostPost',
		'as'   => 'new_post',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> ['Administrateur', 'Redacteur']
	]);

	Route::post('/limbola/admin/posts/create', [
		'uses' => 'PostController@postPost',
		'as'   => 'new_post',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> ['Administrateur', 'Redacteur']
	]);

	Route::get('/limbola/admin/post/view/{id}', [
		'uses' => 'PostController@viewPost',
		'as'   => 'view_Post',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> ['Administrateur', 'Redacteur']
	]);

	Route::get('/limbola/admin/post/delete/{id}', [
		'uses' => 'PostController@deletePost',
		'as'   => 'delete_post',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> 'Administrateur'
	]);

	Route::get('/limbola/admin/post/publish/{id}', [
		'uses' => 'PostController@publishPost',
		'as'   => 'publier',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> 'Administrateur'
	]);

	Route::get('/limbola/admin/post/unplublish/{id}', [
		'uses' => 'PostController@unpublishPost',
		'as'   => 'retirer',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> 'Administrateur'
	]);

	Route::get('/limbola/admin/post/edit/{id}', [
		'uses' => 'PostController@getEditPost',
		'as'   => 'edit_post',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> ['Administrateur', 'Redacteur']
	]);

	Route::post('/limbola/admin/post/edit/{id}', [
		'uses' => 'PostController@postEditPost',
		'as'   => 'post_edit_post',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> ['Administrateur', 'Redacteur']
	]);


// Likes
	Route::get('/limbola/admin/post/{post_id}/like', [
		'uses' => 'LikeController@toggleLike',
		'as'   => 'like',
	    'middleware' => 'auth'
	]);


// Tags
	Route::get('/limbola/admin/tags', [
		'uses' => 'TagController@getTags',
		'as'   => 'view_tags',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> ['Administrateur', 'Redacteur']
	]);

	Route::get('/limbola/admin/tag/edit/{id}', [
		'uses' => 'TagController@editTag',
		'as'   => 'tag.edit',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> 'Administrateur'
	]);

	Route::get('/limbola/admin/tag/remove/{id}', [
		'uses' => 'TagController@deleteTag',
		'as'   => 'tag.remove',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> 'Administrateur'
	]);

	Route::post('/limbola/admin/tags', [
		'uses' => 'TagController@postTag',
		'as'   => 'tags',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> ['Administrateur', 'Redacteur']
	]);

	Route::post('/limbola/admin/tag/edit/{id}', [
		'uses' => 'TagController@postEditedPost',
		'as'   => 'edited_tag',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> 'Administrateur'
	]);

// Users
	Route::get('/limbola/admin/users', [
		'uses' => 'UserController@getUsers',
		'as'   => 'view_users',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> 'Administrateur'
	]);

	Route::post('/limbola/admin/users', [
		'uses' => 'UserController@postUser',
		'as'   => 'users',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> 'Administrateur'
	]);

	Route::get('/limbola/admin/user/edit/role/{id}', [
		'uses' => 'UserController@getUserRole',
		'as'   => 'edit_user_role',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> 'Administrateur'
	]);

	Route::post('/limbola/admin/user/edit/role/{id}', [
		'uses' => 'UserController@postUserRole',
		'as'   => 'post_edit_user_role',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> 'Administrateur'
	]);


	// User Profile
	Route::get('/limbola/admin/profile/{id}', [
	  'uses'  => 'UserController@getUserProfile',
	  'as'    => 'profile',
	  'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> ['Administrateur', 'Redacteur']
	]);

	Route::post('/limbola/admin/profile', [
	  'uses'  => 'UserController@postUserProfile',
	  'as'    => 'profile_update',
	  'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> ['Administrateur', 'Redacteur']
	]);

	// Upload user image
	Route::post('/limbola/admin/password', [
	  'uses'  => 'UserController@upload_avatar',
	  'as'    => 'upload_profile',
	  'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> ['Administrateur', 'Redacteur']
	]);

	Route::get('/limbola/admin/user/delete/{id}', [
		'uses' => 'UserController@deleteUser',
		'as'   => 'delete_User',
	    'middleware' => 'auth',
	    'middleware' => 'roles',
	    'roles'	=> ['Administrateur', 'Redacteur']
	]);

	// Sign in
	Route::get('/limbola/admin/login', [
	  'uses'  => 'UserController@getSignin',
	  'as'    => 'login'
	])->name('login');

	Route::post('/limbola/admin/login', [
	  'uses'  => 'UserController@postSignin',
	  'as'    => 'login'
	]);

	// Sing out
	Route::get('/limbola/admin/logout', [
	  'uses'  => 'UserController@getSignout',
	  'as'    => 'logout'
	]);


