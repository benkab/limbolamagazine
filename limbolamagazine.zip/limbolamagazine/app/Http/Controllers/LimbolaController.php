<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class LimbolaController extends Controller
{
    // Get index
    public function getLimbola()
    {
    	return view('limbola.views.index');
    }
}
