<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Like;
use App\User;
use App\Post;
use App\Http\Requests;
use Illuminate\Support\Facades\Auth;
use DB;

class LikeController extends Controller
{
    public function toggleLike($post_id)
    {
    	$user_id 		= Auth::user()->id;
    	$check 			= DB::table('likes')->where('user_id', $user_id)
    										->where('post_id', $post_id)
    										->get();

    	$like 	= Like::where('user_id', $user_id)->where('post_id', $post_id)->first();

    	if($check){
    		$like->update([
    			'liked' => false
    		]);
    	}
    	else{

    			$newLike 			= new Like();
	    		$newLike->user_id	= $user_id;
	    		$newLike->post_id	= $post_id;
	    		$newLike->liked		= true;

	    		if($like){
	    			$like->update([
		    			'liked' => true
		    		]);
	    		}
	    		else{
	    			$newLike->save();
	    		}
	    		
    	}

    	return redirect()->back();
    }
}
