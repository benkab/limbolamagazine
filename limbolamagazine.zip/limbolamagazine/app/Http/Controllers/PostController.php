<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Tag;
use App\User;
use App\Post;
use App\Category;
use Illuminate\Support\Facades\Auth;
use DateTime;
use App\Http\Requests;
use Image;
use DB;

class PostController extends Controller
{
    // Retrieve posts
    public function getPosts()
    {
        $posts          = Post::paginate(6);
        
    	return view('admin.views.posts.index', ['posts' => $posts]);
    }

    // Get tags to post with
    public function getPostPost()
    {
    	$tags = Tag::all();
        $categories     = Category::all();

    	return view('admin.views.posts.create', ['tags' => $tags, 'categories' => $categories]);
    }

    // Post post
    public function postPost(Request $request)
    {

        // Retrieve data from the request
        $title      = $request['title'];
        $body       = $request['body'];
        $tags       = $request['tags'];
        $category   = $request['category'];
        $status     = $request->input('status', false);
        $now        = new DateTime();

        // Create the slug
        $slug = str_slug($title, "-");

        $status_bool_value = filter_var($status, FILTER_VALIDATE_BOOLEAN);

        // Validate the request
        $this->validate($request, [
            'title' => 'required',
            'body'  => 'required',
            'tags'  => 'required',
            'cover' => 'required',
            'category'  => 'required'
        ]);

            $cover = $request->file('cover');

            // Set the file name
            $filename = $slug . '.' . $cover->getClientOriginalExtension();
            
            // Add new image to the public folder
            Image::make($cover)->save(public_path('/uploads/posts/' . $filename));

        // Create an instance of the Post
        $post               = new Post();
        $post->cover        = $filename;
        $post->title        = $title;
        $post->slug         = $slug;
        $post->body         = $body;
        $post->status       = $status_bool_value;
        $post->user_id      = Auth::user()->id;
        $post->category_id  = $category;
        $post->published_at = $now;

        // Create the post
        $post->save();
 
        // Save tags
        $post->tags()->sync($tags);

        alert()->success('Success', 'Un nouvel article a ete ajoute');
        
        return redirect()->route('view_posts');
    }

    // View Post
    public function viewPost($id)
    {
        $post       = Post::where('id', $id)->first();

        return view('admin.views.posts.view', ['post' => $post]);
    }

    // Get post to edit
    public function getEditPost($id)
    {
        $post = Post::find($id);
        $tags = Tag::all();
        $categories = Category::all();

        return view('admin.views.posts.edit', ['post' => $post, 'categories' => $categories, 'tags' => $tags]);
    }

    // Post edited post
    public function postEditPost(Request $request, $id)
    {
        $title      = $request['title'];
        $body       = $request['body'];
        $tags       = $request['tags'];
        $category   = $request['category'];
        $now        = new DateTime();

        // Create the slug
        $slug = str_slug($title, "-");

        // Validate the request
        $this->validate($request, [
            'title'     => 'required',
            'body'      => 'required',
            'tags'      => 'required'
        ]);

        $post = Post::find($id);

        if($request->hasFile('cover'))
        {

            $cover = $request->file('cover');

            // Set the file name
            $filename = $slug . '_'  . $cover->getClientOriginalExtension();

            // Delete user's previous pictures
            $path = '../public/uploads/posts/' . $post->cover  . '*';
            $files = glob($path);
            foreach ($files as $file) {
              unlink($file);
            }
            
            // Add new image to the public folder
            Image::make($cover)->save(public_path('/uploads/posts/' . $filename));

            $post->update([

                'title' => $title,
                'body'  => $body,
                'slug'  => $slug,
                'cover' => $filename
            ]);

            // Save tags
            $post->tags()->sync($tags);
        }
        else{

            $post->update([

                'title' => $title,
                'body'  => $body,
                'slug'  => $slug
            ]);

            // Save tags
            $post->tags()->sync($tags);
        }

        alert()->success('Success', 'Cet article a ete modifie');

        return redirect()->route('view_posts');

    }

    // Delete post
    public function deletePost($id)
    {

        $post = Post::where('id', $id)->first();

            // Delete post's previous pictures
            $path = '../public/uploads/posts/' . $post->slug  . '*';
            $files = glob($path);
            foreach ($files as $file) {
              unlink($file);
            }


        // Delete post
            $post->delete();

        alert()->success('Success', 'Cet article a ete supprime');
        
        return redirect()->route('view_posts');
    }

    // Public post
    public function publishPost($id)
    {

        $post = Post::where('id', $id)->first();
        $now        = new DateTime();

        // Delete post
        $post->update([
            'status' => true,
            'published_at'  => $now
        ]);

        alert()->success('Success', 'Cet article a ete publie');
        
        return redirect()->back();
    }

    // Remove post from timeline
    public function unpublishPost($id)
    {

        $post = Post::where('id', $id)->first();

        // Delete post
        $post->update([
            'status' => false
        ]);

        alert()->success('Success', 'Cet article a ete retire');
        
        return redirect()->back();
    }
    
}
