<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Tag;
use DB;

use App\Http\Requests;

class TagController extends Controller
{
	// Retrieve Tags
    public function getTags()
    {

    	$tags       = Tag::paginate(6);

        return view('admin.views.tags.index', ['tags' => $tags]);
    }

    // Post Tag
    public function postTag(Request $request)
    {
    	// Retrieve data from the request
    	$description	= $request['description'];
    	$status			= 0;


    	// Validate the request
    	$this->validate($request, [
    		'description'		=> 'alpha | max:50 | required | unique:tags,description'
    	]);


    	// Create an instance of the Tag
    	$tag 				= new Tag();
    	$tag->description 	= $description;
    	$tag->status 		= $status;

    	// Create the user
    	$tag->save();

        alert()->success('Success', 'Un nouveau mot cle a ete ajoute');
    	
        return redirect()->route('view_tags');


    }

    // Edit Tag
    public function editTag(Request $request, $id)
    {

    	$tag = Tag::where('id', $id)->first();

    	$tags = Tag::paginate(6);

    	return view('admin.views.tags.edit', ['tags' => $tags, 'tag' => $tag]);
    }

    // Post Edited Tag
    public function postEditedPost(Request $request, $id)
    {
    	$tag = Tag::where('id', $id)->first();

    	// Retrieve data from the request
    	$description	= $request['description'];

    	// Validate the request
    	$this->validate($request, [
    		'description'		=> 'alpha | max:50 | required | unique:tags,description'
    	]);

    	$tag->description 	= $description;
    	$tag->update();

        alert()->success('Success', 'Le mot cle a ete modifie');

    	return redirect()->route('view_tags');

    }

    // Delete Tag
    public function deleteTag($id)
    {
    	$tag = Tag::where('id', $id)->first();
    	$tag->delete();

        alert()->success('Success', 'Le mot cle a ete supprime');

    	return redirect()->back();
    }
}
