<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Task;
use Illuminate\Support\Facades\Auth;

class TaskController extends Controller
{
    // get tasks
    public function getTasks()
    {
    	$tasks = Task::paginate(4);

    	return view('admin.views.tasks.index', ['tasks' => $tasks]);
    }

    // Post tasks
    public function postTask(Request $request)
    {
    	// Retrieve data from the request
        $description    = $request['description'];
        $date       	= $request['date'];
        $time       	= $request['time'];
        $type	     	= $request->input('type', false);
        $user_id		= Auth::user()->id;

        // Create the slug

        $type_bool_value = filter_var($type, FILTER_VALIDATE_BOOLEAN);

        // Validate the request
        $this->validate($request, [
            'description' 	=> 'required',
            'date'  		=> 'required'
        ]);

        // Create an instance of the Post
        $task               = new Task();
        $task->description 	= $description;
        $task->date         = $date;
        $task->time         = $time;
        $task->type         = $type_bool_value;
        $task->user_id      = Auth::user()->id;


        // Create the Task
        $task->save();

        alert()->success('Success', 'Une nouvelle tache a ete ajoute');

    	return redirect()->route('view_tasks');
    }
}
