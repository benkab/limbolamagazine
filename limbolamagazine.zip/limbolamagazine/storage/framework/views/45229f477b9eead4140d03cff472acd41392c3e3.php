<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('admin.includes.top-page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- nav-side -->
	<div class="col-lg-2 hidden-md hidden-sm hidden-xs display-cell" id="nav-side">
	    <ul>
	        <li class="link">
	            <a href="">
	                <span class="icon ion-ios-keypad"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Home</span>
	            </a>
	        </li>
	        <li class="link active-link">
	            <a href="<?php echo e(route('view_posts')); ?>">
	                <span class="icon ion-ios-paper"></span>
	                <span id="text">Articles</span>
	                <small class="label label-default pull-right hidden-md hidden-sm hidden-xs">30</small>
	            </a>
	        </li>
	        <?php if(Auth::user()->isAdmin()): ?>
	        <li class="link">
	            <a href="<?php echo e(route('view_users')); ?>">
	                <span class="icon ion-android-people"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">L'Equipe</span>
	            </a>
	        </li>
	        
	        <li class="link">
	            <a href="<?php echo e(route('view_visitors')); ?>">
	                <span class="icon ion-ios-people"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Visiteurs</span>
	                <small class="label label-default pull-right hidden-md hidden-sm hidden-xs">30</small>
	            </a>
	        </li>
	        <?php endif; ?>
	        <li class="link">
	            <a href="">
	                <span class="icon ion-chatbox-working"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Commentaires</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="<?php echo e(route('view_tags')); ?>">
	                <span class="icon ion-link"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Mots cles</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="<?php echo e(route('view_tasks')); ?>">
	                <span class="icon ion-android-calendar"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Agenda</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="<?php echo e(route('profile', ['id' => Auth::user()->id ])); ?>">
	                <span class="icon ion-android-contact"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Mon profil</span>
	            </a>
	        </li>
	    </ul>
	</div>
	<!-- End nav-side -->
	<?php echo $__env->make('admin.includes.nav-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<!-- Page Content -->
	<div class="row clearfix" id="page-content">
       <div class="row clearfix" id="tags">
       		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
       			<div class="panel panel-default">
       				<div class="panel-body" id="view-post">
						<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 thumbnail">
							<img src="<?php echo e(URL::to('../public/uploads/posts/').'/'.$post->cover); ?>" alt="post-image" id="post-image">
						</div>
						<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
							<h3><?php echo e($post->title); ?></h3>
							<p class="lign"></p>
							<ul id="links">
								<li>
									<a href="<?php echo e(route('view_posts')); ?>"><span class="icon ion-ios-undo"></span></a>
								</li>
								<?php if((Auth::user()->email === $post->user->email) || Auth::user()->isAdmin()): ?>
									<li>
										<a href="<?php echo e(route('edit_post', ['id' => $post->id])); ?>"><span class="icon ion-edit"></span></a>
									</li>
								<?php endif; ?>
								<?php if(Auth::user()->isAdmin()): ?>
								<li>
									<a href="<?php echo e(route('delete_post', ['id' => $post->id])); ?>"><span class="icon ion-trash-b"></span></a>
								</li>
								<?php endif; ?>
							</ul>
							<div class="text-left" id="view-category">
								<span><?php echo e($post->categories->description); ?></span>
							</div>
							<p id="view-status">
								<?php if($post->status == 1): ?>
									<span class="label label-success">Publi&eacute;</span>
									<br>
									<small><?php echo e($post->created_at->diffForHumans()); ?></small>
								<?php else: ?>
									<span class="label label-default">Non Publi&eacute;</span>
								<?php endif; ?>	
							</p>
							
							<h4 id="auther"><span>Par&nbsp;&nbsp;</span><?php echo e($post->user->firstname); ?>&nbsp;<?php echo e($post->user->lastname); ?></h4>

							<p>
								<a href="" id="star">
							      	<span class="icon ion-star"></span>
							    </a>
							</p>
							<span id="like-block">
								<a href="" >
							      	<span class="icon ion-ios-heart" id="isLiked"></span>
							    </a>
							    <span id="likes">22&nbsp;Likes</span>
							</span>
							<a href="" id="comments">
								10 Commentaires
							</a>
							
							<ul id="links">
								<?php if($post->status == 0): ?>
								<li>
									<?php if(Auth::user()->isAdmin()): ?>
										<li>
											<a href="<?php echo e(route('publier', ['id' => $post->id] )); ?>" type="button" class="btn btn-sm btn-info" id="publier">
												<span>Publier</span>
											</a>
										</li>
									<?php endif; ?>
								</li>
								<?php else: ?>
									<?php if(Auth::user()->isAdmin()): ?>
										<li>
											<a href="<?php echo e(route('retirer', ['id' => $post->id] )); ?>" type="button" class="btn btn-sm btn-danger" id="publier">
												<span>Retirer</span>
											</a>
										</li>
									<?php endif; ?>
								<?php endif; ?>	
							</ul>
							<hr>
							<ul id="post-tags">
								<?php foreach( $post->tags->lists('description') as $tag): ?>
								<li><?php echo e($tag); ?></li>
								<?php endforeach; ?>
							</ul>
							<hr>
						</div>
						<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 fr-view">
							<h5 id="post-body"><?php echo $post->body; ?></h5>
						</div>
						<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
							
						</div>
       				</div>
       			</div>
       		</div>
       </div>
       <div class="row">
       		<p id="hidden">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi dicta illo ad a, quas numquam, eius perspiciatis amet eos possimus dolor! 
		       	Magnam temporibus dolore ullam consectetur distinctio minus elit. Sequi dicta illo ad a, quas numquam, eius perspiciatis amet eos p
		    </p>
       </div>
       
    </div>
	<!-- End Page Content -->

	<?php echo $__env->make('admin.includes.bottom-page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>