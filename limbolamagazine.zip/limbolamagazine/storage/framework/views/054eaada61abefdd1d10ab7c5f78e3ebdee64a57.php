<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('admin.includes.top-page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- nav-side -->
	<div class="col-lg-2 hidden-md hidden-sm hidden-xs display-cell" id="nav-side">
	    <ul>
	        <li class="link">
	            <a href="">
	                <span class="icon ion-ios-keypad"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Home</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="<?php echo e(route('view_posts')); ?>">
	                <span class="icon ion-ios-paper"></span>
	                <span id="text">Articles</span>
	                <small class="label label-default pull-right hidden-md hidden-sm hidden-xs">30</small>
	            </a>
	        </li>
	        <?php if(Auth::user()->isAdmin()): ?>
	        <li class="link">
	            <a href="<?php echo e(route('view_users')); ?>">
	                <span class="icon ion-android-people"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">L'Equipe</span>
	            </a>
	        </li>
	        <li class="link active-link">
	            <a href="<?php echo e(route('view_visitors')); ?>">
	                <span class="icon ion-ios-people"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Visiteurs</span>
	                <small class="label label-default pull-right hidden-md hidden-sm hidden-xs">30</small>
	            </a>
	        </li>
	        <?php endif; ?>
	        <li class="link">
	            <a href="<?php echo e(route('view_comments')); ?>">
	                <span class="icon ion-chatbox-working"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Commentaires</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="<?php echo e(route('view_tags')); ?>">
	                <span class="icon ion-link"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Mots cles</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="<?php echo e(route('view_tasks')); ?>">
	                <span class="icon ion-android-calendar"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Agenda</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="<?php echo e(route('profile', ['id' => Auth::user()->id ])); ?>">
	                <span class="icon ion-android-contact"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Mon profil</span>
	            </a>
	        </li>
	    </ul>
	</div>
	<!-- End nav-side -->
	<?php echo $__env->make('admin.includes.nav-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<!-- Page Content -->
	<div class="row clearfix" id="page-content">
       <div class="row clearfix" id="tags">
       		<div class="col-xs-12">
       			<div class="panel panel-default" id="visitors">
       				<div class="panel-body">
						<h5>
							Les visiteurs
							<span class="icon ion-ios-people pull-right"></span>
						</h5>
						<p class="lign"></p>
						<table class="table">
							<tr>
								<td>Photo</td>
								<td>Pr&eacute;nom</td>
								<td class="hidden-xs hidden-sm">Nom</td>
								<td class="hidden-xs hidden-sm">Email</td>
								<td class="text-center">Status</td>
								<td class="text-center">Actions</td>
							</tr>
							<?php foreach($users as $user): ?>
								<?php if($user->isVisitor()): ?>
								<tr>
									<td>&nbsp;&nbsp;<img src="<?php echo e(URL::to('../public/uploads/avatars/').'/'.$user->avatar); ?>" alt="user-image" id="user-photo"></td>
									<td>&nbsp;&nbsp;<?php echo e($user->firstname); ?> </td>
									<td class="hidden-xs hidden-sm">&nbsp;&nbsp;<?php echo e($user->lastname); ?></td>
									<td class="hidden-xs hidden-sm">&nbsp;&nbsp;<?php echo e($user->email); ?></td>
									<?php if($user->status == 1): ?>
									<td class="text-center"><span class="label label-success">Actif</span></td>
									<?php else: ?>
									<td class="text-center"><span class="label label-default">Inactif</span></td>
									<?php endif; ?>
									<td class="text-center">
										<?php if($user->status == 0): ?>
										<a href="<?php echo e(route('unblock', ['id' => $user->id])); ?>" type="button" disabled>
											<span class="icon ion-android-checkmark-circle"></span>
										</a>
										<?php else: ?>
										<a href="<?php echo e(route('block', ['id' => $user->id])); ?>" type="button" disabled>
											<span class="icon ion-minus-circled"></span>
										</a>
										<?php endif; ?>
										<a href="<?php echo e(route('delete_User', ['id' => $user->id])); ?>" type="button" disabled>
											<span class="icon ion-android-delete"></span>
										</a>
									</td>
								</tr>
								<?php endif; ?>
							<?php endforeach; ?>
						</table>
						<hr>
						<small id="render"><?php echo $users->render(); ?></small>
								
       				</div>
       			</div>
       		</div>
       		
       </div>
       <div class="row">
       		<p id="hidden">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi dicta illo ad a, quas numquam, eius perspiciatis amet eos possimus dolor! 
		       	Magnam temporibus dolore ullam consectetur distinctio minus elit. Sequi dicta illo ad a, quas numquam, eius perspiciatis amet eos p
		    </p>
       </div>
       
    </div>
	<!-- End Page Content -->

	<?php echo $__env->make('admin.includes.bottom-page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>