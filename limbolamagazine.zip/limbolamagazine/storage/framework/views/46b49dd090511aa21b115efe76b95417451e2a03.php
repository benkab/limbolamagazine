<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('admin.includes.top-page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- nav-side -->
	<div class="col-lg-2 hidden-md hidden-sm hidden-xs display-cell" id="nav-side">
	    <ul>
	        <li class="link">
	            <a href="">
	                <span class="icon ion-ios-keypad"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Home</span>
	            </a>
	        </li>
	        <li class="link active-link">
	            <a href="<?php echo e(route('view_posts')); ?>">
	                <span class="icon ion-ios-paper"></span>
	                <span id="text">Articles</span>
	                <small class="label label-default pull-right hidden-md hidden-sm hidden-xs">30</small>
	            </a>
	        </li>
	        <?php if(Auth::user()->isAdmin()): ?>
	        <li class="link">
	            <a href="<?php echo e(route('view_users')); ?>">
	                <span class="icon ion-android-people"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">L'Equipe</span>
	            </a>
	        </li>
	        
	        <li class="link">
	            <a href="<?php echo e(route('view_visitors')); ?>">
	                <span class="icon ion-ios-people"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Visiteurs</span>
	                <small class="label label-default pull-right hidden-md hidden-sm hidden-xs">30</small>
	            </a>
	        </li>
	        <?php endif; ?>
	        <li class="link">
	            <a href="">
	                <span class="icon ion-chatbox-working"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Commentaires</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="<?php echo e(route('view_tags')); ?>">
	                <span class="icon ion-link"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Mots cles</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="<?php echo e(route('view_tasks')); ?>">
	                <span class="icon ion-android-calendar"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Agenda</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="<?php echo e(route('profile', ['id' => Auth::user()->id ])); ?>">
	                <span class="icon ion-android-contact"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Mon profil</span>
	            </a>
	        </li>
	    </ul>
	</div>
	<!-- End nav-side -->
	<?php echo $__env->make('admin.includes.nav-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<!-- Page Content -->
	<div class="row clearfix" id="page-content">
       <div class="row clearfix" id="tags">
       		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
       			<div class="panel panel-default">
       				<div class="panel-body" id="posts">
						<h5>
							Tous les articles
						</h5>
						<a href="<?php echo e(route('new_post')); ?>" class="pull-right btn btn-sm btn-default" id="new-post-link">
							<span class="icon ion-compose"></span>
							<span class="hidden-sm hidden-xs">&nbsp;R&eacute;diger un article</span>
						</a>
						<p class="lign"></p>
						<?php foreach($posts as $post): ?>
						<div class="row">
							<div class="col-md-1 text-right hidden-sm hidden-xs">
								<img src="<?php echo e(URL::to('../public/uploads/posts/').'/'.$post->cover); ?>" alt="post-image" id="all-post-image">
							</div>
							<div class="col-md-5" id="article-title">
								<div class="col-xs-12">
									<p class="text-left"><?php echo e($post->title); ?></p>
									<span><?php echo e($post->created_at->diffForHumans()); ?></span>
									<p id="article-auther"><span class="icon ion-edit"></span>&nbsp;<?php echo e($post->user->firstname); ?>&nbsp;<?php echo e($post->user->lastname); ?></p>
									<hr class="hidden-xs hidden-sm">
								</div>
								<br>
							</div>
							<div class="col-md-2 text-left" id="view-category">
								<div class="col-xs-12" id="view-category-inner">
									<span><?php echo e($post->categories->description); ?></span>
								</div>
							</div>
							<div class="col-md-2 artiicle-status">
								<div class="col-xs-12">
									<?php if($post->status == 1): ?>
										<span class="label label-success">Publi&eacute;</span>
									<?php else: ?>
										<span class="label label-default">Non Publi&eacute;</span>
									<?php endif; ?>	
						        </div>
							</div>
							<div class="col-md-2 interaction">
								<div class="col-xs-12">
									<div class="artiicles-actions">
										<a href="<?php echo e(route('view_Post', ['id' => $post->id])); ?>" class="btn btn-xs btn-default" role="button" >
											<span class="icon ion-folder" aria-hidden="true"></span> 
										</a>
										<?php if((Auth::user()->email === $post->user->email) || Auth::user()->isAdmin()): ?>
										<a href="<?php echo e(route('edit_post', ['id' => $post->id])); ?>" class="btn btn-xs btn-default btn-info" role="button">
											<span class="icon ion-compose" aria-hidden="true"></span> 
										</a>
										<?php endif; ?>
										<?php if(Auth::user()->isAdmin()): ?>
										<a href="<?php echo e(route('delete_post', ['id' => $post->id])); ?>" class="btn btn-xs btn-default btn-danger" role="button">
											<span class="icon ion-trash-b" aria-hidden="true"></span> 
										</a>
										<?php endif; ?>
										
									</div>
									<hr class="hidden-lg hidden-md">
								</div>

							</div>
						</div>
						<?php endforeach; ?>
						<small id="render"><?php echo $posts->render(); ?></small>
       				</div>
       			</div>
       		</div>
       </div>
       <div class="row">
       		<p id="hidden">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi dicta illo ad a, quas numquam, eius perspiciatis amet eos possimus dolor! 
		       	Magnam temporibus dolore ullam consectetur distinctio minus elit. Sequi dicta illo ad a, quas numquam, eius perspiciatis amet eos p
		      
		    </p>
       </div>
       
    </div>
	<!-- End Page Content -->

	<?php echo $__env->make('admin.includes.bottom-page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>