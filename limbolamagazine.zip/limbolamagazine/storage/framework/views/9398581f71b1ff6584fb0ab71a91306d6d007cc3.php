<?php $__env->startSection('content'); ?>
	<div class="col-xs-8 col-xs-offset-2">
		Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magnam dignissimos inventore, 
		tenetur tempore omnis aliquid ducimus aperiam eos, earum eligendi eaque et obcaecati exercitationem 
		consequatur adipisci asperiores qui, harum expedita. Officiis facilis nostrum corporis mollitia 
		molestiae fugit quasi quod, blanditiis illum minus autem doloremque ipsa, necessitatibus atque nesciunt 
		quidem neque, qui, expedita! Eum earum deleniti totam eveniet consequuntur, fuga laboriosam perferendis 
		quaerat fugiat quia tempora, aliquid facere assumenda, quasi? Quia autem minus perferendis repudiandae 
		praesentium, in est ad quos consequuntur rem laboriosam facere sunt sed corporis. Illum eligendi ex maiores, 
		architecto nulla explicabo nihil unde tempore quis officiis dignissimos dolorum dolor voluptatibus aperiam 
		provident, sequi magni veritatis ea. Est omnis delectus eum, dolore voluptatem velit veritatis aliquam debitis 
		earum. Eius illo nostrum cumque quaerat omnis, libero labore nulla adipisci excepturi non illum magni quis sapiente 
		fuga inventore dicta earum tempore aut, qui deserunt deleniti animi, enim quod quam reprehenderit. Voluptate, 
		quae sunt maiores explicabo eligendi accusantium natus dolores neque minima soluta unde, odit quo, quos assumenda 
		autem inventore consequatur maxime dolore incidunt! Laudantium asperiores cum porro, minima voluptatum, nostrum ut 
		debitis labore nisi, laborum dignissimos quo dolores perspiciatis voluptates ab. Asperiores minima laborum 
		reprehenderit assumenda, quaerat ad magnam obcaecati cupiditate rerum recusandae eveniet quam, totam incidunt 
		consectetur corporis eligendi. Sunt eum, hic ipsa tempore odit incidunt minima animi dicta. Velit, cumque non 
		doloribus magnam praesentium adipisci enim voluptas explicabo veritatis ipsum! Porro tempora nobis nemo ipsam,
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>