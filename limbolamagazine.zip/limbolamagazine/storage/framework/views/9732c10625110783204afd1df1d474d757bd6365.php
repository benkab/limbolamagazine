<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('admin.includes.top-page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- nav-side -->
	<div class="col-lg-2 hidden-md hidden-sm hidden-xs display-cell" id="nav-side">
	    <ul>
	        <li class="link">
	            <a href="">
	                <span class="icon ion-ios-keypad"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Home</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="<?php echo e(route('view_posts')); ?>">
	                <span class="icon ion-ios-paper"></span>
	                <span id="text">Articles</span>
	                <small class="label label-default pull-right hidden-md hidden-sm hidden-xs">30</small>
	            </a>
	        </li>
	        <?php if(Auth::user()->isAdmin()): ?>
	        <li class="link">
	            <a href="<?php echo e(route('view_users')); ?>">
	                <span class="icon ion-android-people"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">L'Equipe</span>
	            </a>
	        </li>
	        
	        <li class="link">
	            <a href="<?php echo e(route('view_visitors')); ?>">
	                <span class="icon ion-ios-people"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Visiteurs</span>
	                <small class="label label-default pull-right hidden-md hidden-sm hidden-xs">30</small>
	            </a>
	        </li>
	        <?php endif; ?>
	        <li class="link">
	            <a href="">
	                <span class="icon ion-chatbox-working"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Commentaires</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="<?php echo e(route('view_tags')); ?>">
	                <span class="icon ion-link"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Mots cles</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="<?php echo e(route('view_tasks')); ?>">
	                <span class="icon ion-android-calendar"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Agenda</span>
	            </a>
	        </li>
	        <li class="link active-link">
	            <a href="<?php echo e(route('profile', ['id' => Auth::user()->id ])); ?>">
	                <span class="icon ion-android-contact"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Mon profil</span>
	            </a>
	        </li>
	    </ul>
	</div>
	<!-- End nav-side -->
	<?php echo $__env->make('admin.includes.nav-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<!-- Page Content -->
	<div class="row clearfix" id="page-content">
       <div class="row clearfix" id="tags">
       		<div class="col-lg-4 col-md-4 col-lg-offset-2 col-md-offset-2 col-sm-12 col-xs-12">
       			<div class="panel panel-default" id="profile">
       				<div class="panel-body">
						<h5>
							Mettre &agrave; jour mon profile
							<span class="icon ion-android-contact pull-right"></span>
						</h5>
						<p class="lign"></p>
						<div class="row">
						  <div class="col-xs-8 col-xs-offset-2 thumbnail">
						  	<img src="<?php echo e(URL::to('../public/uploads/avatars/').'/'.Auth::user()->avatar); ?>" alt="user-image" id="user-profile-image">		
						  </div>
						</div>
						<form class="form-vertical" action="<?php echo e(route('profile_update')); ?>" method="Post" role="form">
							<div class="form-group<?php echo e($errors->has('Prenom') ? ' has-error' : ''); ?>">
								<input type="text" name="Prenom" id="Prenom" class="form-control" placeholder="Pr&eacute;nom" value="<?php echo e(Request::old('Prenom') ?: Auth::user()->firstname); ?>">
								<?php if($errors->has('Prenom')): ?>
						        <span class="help-block"><?php echo e($errors->first('Prenom')); ?></span>
						        <?php endif; ?>
							</div>
							<div class="form-group<?php echo e($errors->has('Nom') ? ' has-error' : ''); ?>">
								<input type="text" name="Nom" id="Nom" class="form-control" placeholder="Nom" value="<?php echo e(Request::old('Nom') ?: Auth::user()->lastname); ?>">
								<?php if($errors->has('Nom')): ?>
						        <span class="help-block"><?php echo e($errors->first('Nom')); ?></span>
						        <?php endif; ?>
							</div>
							<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
								<input type="email" name="email" id="email" class="form-control" placeholder="Addresse email" value="<?php echo e(Request::old('email') ?: Auth::user()->email); ?>">
								<?php if($errors->has('email')): ?>
						        <span class="help-block"><?php echo e($errors->first('email')); ?></span>
						        <?php endif; ?>
							</div>
							<button class="btn btn-sm btn-default">Soumettre</button>
							<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
						</form>
       				</div>
       			</div>
       		</div>
       		<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
       			<div class="panel panel-default">
       				<div class="panel-body">
						<h5>
							Changer ma photo de profil
							<span class="icon ion-key pull-right"></span>
						</h5>
						<p class="lign"></p>
						<form class="form-vertical" action="<?php echo e(route('upload_profile')); ?>" method="Post" role="form" enctype="multipart/form-data">
							<div class="form-group<?php echo e($errors->has('avatar') ? ' has-error' : ''); ?>">
								<input type="file" name="avatar" id="avatar" class="form-control" accept=".png, .jpg">
								<?php if($errors->has('avatar')): ?>
						        <span class="help-block"><?php echo e($errors->first('avatar')); ?></span>
						        <?php endif; ?>
							</div>
							<button class="btn btn-sm btn-default">Soumettre</button>
							<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
						</form>
       				</div>
       			</div>
       		</div>
       </div>
       <div class="row">
       		<p id="hidden">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi dicta illo ad a, quas numquam, eius perspiciatis amet eos possimus dolor! 
		       	Magnam temporibus dolore ullam consectetur distinctio minus elit. Sequi dicta illo ad a, quas numquam, eius perspiciatis amet eos p
		      
		    </p>
       </div>
       
    </div>
	<!-- End Page Content -->

	<?php echo $__env->make('admin.includes.bottom-page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>