<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('admin.includes.top-page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- nav-side -->
	<div class="col-lg-2 hidden-md hidden-sm hidden-xs display-cell" id="nav-side">
	    <ul>
	        <li class="link">
	            <a href="">
	                <span class="icon ion-ios-keypad"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Home</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="<?php echo e(route('view_posts')); ?>">
	                <span class="icon ion-ios-paper"></span>
	                <span id="text">Articles</span>
	                <small class="label label-default pull-right hidden-md hidden-sm hidden-xs">30</small>
	            </a>
	        </li>
	        <?php if(Auth::user()->isAdmin()): ?>
	        <li class="link">
	            <a href="<?php echo e(route('view_users')); ?>">
	                <span class="icon ion-android-people"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">L'Equipe</span>
	            </a>
	        </li>
	       
	        <li class="link">
	            <a href="<?php echo e(route('view_visitors')); ?>">
	                <span class="icon ion-ios-people"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Visiteurs</span>
	                <small class="label label-default pull-right hidden-md hidden-sm hidden-xs">30</small>
	            </a>
	        </li>
	         <?php endif; ?>
	        <li class="link">
	            <a href="">
	                <span class="icon ion-chatbox-working"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Commentaires</span>
	            </a>
	        </li>
	        <li class="link active-link">
	            <a href="<?php echo e(route('view_tags')); ?>">
	                <span class="icon ion-link"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Mots cles</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="<?php echo e(route('view_tasks')); ?>">
	                <span class="icon ion-android-calendar"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Agenda</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="<?php echo e(route('profile', ['id' => Auth::user()->id ])); ?>">
	                <span class="icon ion-android-contact"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Mon profil</span>
	            </a>
	        </li>
	    </ul>
	</div>
	<!-- End nav-side -->
	<?php echo $__env->make('admin.includes.nav-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<!-- Page Content -->
	<div class="row clearfix" id="page-content">
       <div class="row clearfix" id="tags">
       		<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
       			<div class="panel panel-default">
       				<div class="panel-body">
						<h5>
							Nouveau mot cl&eacute;
							<span class="icon ion-link pull-right"></span>
						</h5>
						<p class="lign"></p>
						<form class="form-vertical" action="<?php echo e(route('tags')); ?>" method="Post" role="form">
							<div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
								<textarea name="description" id="description" rows="3" class="form-control" placeholder="Description"><?php echo e(Request::old('description')); ?></textarea>
								<?php if($errors->has('description')): ?>
						        <span class="help-block"><?php echo e($errors->first('description')); ?></span>
						        <?php endif; ?>
							</div>
							<button class="btn btn-sm btn-default">Soumettre</button>
							<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
						</form>
       				</div>
       			</div>
       		</div>
       		<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
       			<div class="panel panel-default" id="panel-with-paging">
       				<div class="panel-body">
						<h5>
							Tous les mots cl&eacute;s
							<span class="icon ion-android-list pull-right"></span>
						</h5>
						<p class="lign"></p>
						<table class="table">
							<tr>
								<td>Description</td>
								<td class="text-center">Status</td>
								<td class="hidden-sm hidden-xs text-center">Date de cr&eacute;ation</td>
								<td class="text-center">Actions</td>
							</tr>
							<?php foreach($tags as $tag): ?>
							<tr>
								<td>&nbsp;&nbsp;&nbsp;<?php echo e($tag->description); ?> </td>
								<?php if($tag->isUsed($tag)): ?>
								<td class="text-center"><small class="label label-success">Utilis&eacute;</small></td>
								<?php else: ?>
								<td class="text-center"><small class="label label-default">Non utilis&eacute;</small></td>
								<?php endif; ?>
								<td class="hidden-sm hidden-xs text-center"><?php echo e($tag->created_at->diffForHumans()); ?></td>
								<td class="text-center">
									<a href="<?php echo e(route('tag.edit', ['id' => $tag->id])); ?>">
										<span class="icon ion-edit"></span>
									</a>
									<?php if(!$tag->isUsed($tag)): ?>
										<?php if(Auth::user()->isAdmin()): ?>
										<a href="<?php echo e(route('tag.remove', ['id' => $tag->id])); ?>">
											<span class="icon ion-trash-b"></span>
										</a>
										<?php endif; ?>
									<?php endif; ?>
								</td>
							</tr>
							<?php endforeach; ?>
						</table>
						<hr>
						<small id="render"><?php echo $tags->render(); ?></small>
       				</div>
       			</div>
       		</div>
       </div>
       <div class="row">
       		<p id="hidden">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi dicta illo ad a, quas numquam, eius perspiciatis amet eos possimus dolor! 
		       	Magnam temporibus dolore ullam consectetur distinctio minus elit. Sequi dicta illo ad a, quas numquam, eius perspiciatis amet eos p
		      
		    </p>
       </div>
       
    </div>
	<!-- End Page Content -->

	<?php echo $__env->make('admin.includes.bottom-page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>