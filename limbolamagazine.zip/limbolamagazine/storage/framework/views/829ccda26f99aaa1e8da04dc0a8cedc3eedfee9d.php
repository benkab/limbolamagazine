<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('admin.includes.top-page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- nav-side -->
	<div class="col-lg-2 hidden-md hidden-sm hidden-xs display-cell" id="nav-side">
	    <ul>
	        <li class="link">
	            <a href="">
	                <span class="icon ion-ios-keypad"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Home</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="<?php echo e(route('view_posts')); ?>">
	                <span class="icon ion-ios-paper"></span>
	                <span id="text">Articles</span>
	                <small class="label label-default pull-right hidden-md hidden-sm hidden-xs">30</small>
	            </a>
	        </li>
	        <li class="link active-link">
	            <a href="<?php echo e(route('view_users')); ?>">
	                <span class="icon ion-android-people"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">L'Equipe</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="">
	                <span class="icon ion-ios-people"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Visiteurs</span>
	                <small class="label label-default pull-right hidden-md hidden-sm hidden-xs">30</small>
	            </a>
	        </li>
	        <li class="link">
	            <a href="">
	                <span class="icon ion-chatbox-working"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Commentaires</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="<?php echo e(route('view_tags')); ?>">
	                <span class="icon ion-link"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Mots cles</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="">
	                <span class="icon ion-android-calendar"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Agenda</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="<?php echo e(route('profile', ['id' => Auth::user()->id ])); ?>">
	                <span class="icon ion-android-contact"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Mon profil</span>
	            </a>
	        </li>
	    </ul>
	</div>
	<!-- End nav-side -->
	<?php echo $__env->make('admin.includes.nav-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<!-- Page Content -->
	<div class="row clearfix" id="page-content">
       <div class="row clearfix" id="users">
       		<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
       			<div class="panel panel-default">
       				<div class="panel-body">
						<h5>
							Mettre &agrave; jour l'agent
							<span class="icon ion-android-contact pull-right"></span>
						</h5>
						<p class="lign"></p>
						<form class="form-vertical" action="<?php echo e(route('post_edit_user_role', ['id' => $user_edit->id])); ?>" method="Post" role="form">
							<div class="form-group">
								<p class="label label-default"  id="user-to-edit"><?php echo e($user_edit->firstname); ?>&nbsp;<?php echo e($user_edit->lastname); ?></p>
								<br>
							</div>
							<div class="form-group<?php echo e($errors->has('role') ? ' has-error' : ''); ?>">
						  		<select name="role[]" class="form-control">
						  			<option value="" disabled selected>Selectioner un role</option>
						  			<?php foreach($roles as $role): ?>
									<option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
									<?php endforeach; ?>
								</select>
								<?php if($errors->has('role')): ?>
						            <span class="help-block"><?php echo e($errors->first('role')); ?></span>
						        <?php endif; ?>
						  	</div>

							<button class="btn btn-sm btn-default">Soumettre</button>
							<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
						</form>
       				</div>
       			</div>
       		</div>
       		<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
       			<div class="panel panel-default" id="panel-with-paging">
       				<div class="panel-body">
						<h5>
							Tous les agents
							<span class="icon ion-android-list pull-right"></span>
						</h5>
						<p class="lign"></p>

						<table class="table">
							<tr>
								<td>Photo</td>
								<td>Pr&eacute;nom</td>
								<td class="hidden-xs hidden-sm">Nom</td>
								<td class="hidden-xs hidden-sm">Email</td>
								<td class="text-center">Role</td>
								<td class="text-center">Actions</td>
							</tr>
							<?php foreach($users as $user): ?>
							<tr>
								<td>&nbsp;&nbsp;<img src="<?php echo e(URL::to('../public/uploads/avatars/').'/'.$user->avatar); ?>" alt="user-image" id="user-photo"></td>
								<td>&nbsp;&nbsp;<?php echo e($user->firstname); ?> </td>
								<td class="hidden-xs hidden-sm">&nbsp;&nbsp;<?php echo e($user->lastname); ?></td>
								<td class="hidden-xs hidden-sm">&nbsp;&nbsp;<?php echo e($user->email); ?></td>
								<?php foreach( $user->roles->lists('name') as $role): ?>
								<td class="text-center"><?php echo e($role); ?></td>
								<?php endforeach; ?>
								<td class="text-center">
									<?php if($user->isAdmin()): ?>
										<a href="<?php echo e(route('profile', ['id' => Auth::user()->id ])); ?>" type="button" disabled>
											<span class="icon ion-edit"></span>
										</a>
									<?php else: ?>
										<a href="<?php echo e(route('edit_user_role', ['id' => $user->id ])); ?>" type="button" disabled>
											<span class="icon ion-edit"></span>
										</a>
									<?php endif; ?>

									<?php if(Auth::user()->email !== $user->email): ?>
									<a href="<?php echo e(route('delete_User', ['id' => $user->id])); ?>" type="button">
										<span class="icon ion-trash-b"></span>
									</a>
									<?php endif; ?>
								</td>
							</tr>
							<?php endforeach; ?>
						</table>
						<hr>
						<small id="render"><?php echo $users->render(); ?></small>
						</table>
       				</div>
       			</div>
       		</div>
       </div>
       <div class="row">
       		<p id="hidden">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi dicta illo ad a, quas numquam, eius perspiciatis amet eos possimus dolor! 
		       	Magnam temporibus dolore ullam consectetur distinctio minus elit. Sequi dicta illo ad a, quas numquam, eius perspiciatis amet eos p
		      
		    </p>
       </div>
    </div>
	<!-- End Page Content -->

	<?php echo $__env->make('admin.includes.bottom-page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>