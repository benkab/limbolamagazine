<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Web fonts -->
        <link href='https://fonts.googleapis.com/css?family=Quicksand:400,700' rel='stylesheet' type='text/css'>
        <!-- links -->
        <link rel="stylesheet" href="{{ URL::to('../bower_components/chosen/chosen.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../bower_components/bootstrap/dist/css/bootstrap.min.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../bower_components/font-awesome/css/font-awesome.min.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../bower_components/Ionicons/css/ionicons.min.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../bower_components/sweetalert/dist/sweetalert.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../bower_components/summernote/dist/summernote.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../bower_components/froala-wysiwyg-editor/css/froala_editor.min.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../bower_components/froala-wysiwyg-editor/css/froala_style.min.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../bower_components/codemirror/lib/codemirror.css') }}" type="text/css">
        <!-- Froala plugins -->
        <link rel="stylesheet" href="{{ URL::to('../bower_components/froala-wysiwyg-editor/css/plugins/code_view.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../bower_components/froala-wysiwyg-editor/css/plugins/colors.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../bower_components/froala-wysiwyg-editor/css/plugins/file.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../bower_components/froala-wysiwyg-editor/css/plugins/fullscreen.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../bower_components/froala-wysiwyg-editor/css/plugins/line_breaker.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../bower_components/froala-wysiwyg-editor/css/plugins/table.css') }}" type="text/css">

        <!-- Custum css -->
        <link rel="stylesheet" href="{{ URL::to('../resources/views/admin/assets/css/default.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../resources/views/admin/assets/css/nav-side.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../resources/views/admin/assets/css/content.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../resources/views/admin/assets/css/nav-header.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../resources/views/admin/assets/css/posts.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../resources/views/admin/assets/css/profile.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../resources/views/admin/assets/css/users.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../resources/views/admin/assets/css/comments.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../resources/views/admin/assets/css/visitors.css') }}" type="text/css">
        <link rel="stylesheet" href="{{ URL::to('../resources/views/admin/assets/css/tasks.css') }}" type="text/css">
        
    <title>Limbola - Magazine</title>
    </head>
    <body>

        @yield('content')

        <script type="text/javascript" src="{{ URL::to('../bower_components/jquery/dist/jquery.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/bootstrap/dist/js/bootstrap.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/chosen/chosen.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../resources/views/admin/assets/js/default.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/sweetalert/dist/sweetalert.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/summernote/dist/summernote.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/froala-wysiwyg-editor/js/froala_editor.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/codemirror/lib/codemirror.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/codemirror/mode/xml/xml.js') }}"></script>
        <!-- Froala plugins -->
        <script type="text/javascript" src="{{ URL::to('../bower_components/froala-wysiwyg-editor/js/plugins/align.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/froala-wysiwyg-editor/js/plugins/code_beautifier.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/froala-wysiwyg-editor/js/plugins/code_view.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/froala-wysiwyg-editor/js/plugins/colors.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/froala-wysiwyg-editor/js/plugins/font_family.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/froala-wysiwyg-editor/js/plugins/font_size.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/froala-wysiwyg-editor/js/plugins/fullscreen.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/froala-wysiwyg-editor/js/plugins/inline_style.min.js') }}"></script>

        <script type="text/javascript" src="{{ URL::to('../bower_components/froala-wysiwyg-editor/js/plugins/line_breaker.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/froala-wysiwyg-editor/js/plugins/lists.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/froala-wysiwyg-editor/js/plugins/font_size.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/froala-wysiwyg-editor/js/plugins/paragraph_format.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/froala-wysiwyg-editor/js/plugins/paragraph_style.min.js') }}"></script>

        <script type="text/javascript" src="{{ URL::to('../bower_components/froala-wysiwyg-editor/js/plugins/quote.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/froala-wysiwyg-editor/js/plugins/table.min.js') }}"></script>
        <script type="text/javascript" src="{{ URL::to('../bower_components/froala-wysiwyg-editor/js/plugins/url.min.js') }}"></script>

        @include('Alerts::alerts')
    </body>
</html>
