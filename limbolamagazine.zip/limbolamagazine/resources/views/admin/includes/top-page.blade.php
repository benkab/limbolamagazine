<div class="container-fluid" class="display-table">
    <div class="row" class="display-row">