@extends('welcome')

@section('content')
	@include('admin.includes.top-page')
	<!-- nav-side -->
	<div class="col-lg-2 hidden-md hidden-sm hidden-xs display-cell" id="nav-side">
	    <ul>
	        <li class="link">
	            <a href="">
	                <span class="icon ion-ios-keypad"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Home</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="{{ route('view_posts') }}">
	                <span class="icon ion-ios-paper"></span>
	                <span id="text">Articles</span>
	                <small class="label label-default pull-right hidden-md hidden-sm hidden-xs">30</small>
	            </a>
	        </li>
	        @if(Auth::user()->isAdmin())
	        <li class="link">
	            <a href="{{ route('view_users') }}">
	                <span class="icon ion-android-people"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">L'Equipe</span>
	            </a>
	        </li>
	        
	        <li class="link">
	            <a href="{{ route('view_visitors') }}">
	                <span class="icon ion-ios-people"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Visiteurs</span>
	                <small class="label label-default pull-right hidden-md hidden-sm hidden-xs">30</small>
	            </a>
	        </li>
	        @endif
	        <li class="link active-link">
	            <a href="{{ route('view_comments') }}">
	                <span class="icon ion-chatbox-working"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Commentaires</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="{{ route('view_tags') }}">
	                <span class="icon ion-link"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Mots cles</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="{{ route('view_tasks') }}">
	                <span class="icon ion-android-calendar"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Agenda</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="{{ route('profile', ['id' => Auth::user()->id ]) }}">
	                <span class="icon ion-android-contact"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Mon profil</span>
	            </a>
	        </li>
	    </ul>
	</div>
	<!-- End nav-side -->
	@include('admin.includes.nav-header')

	<!-- Page Content -->
	<div class="row clearfix" id="page-content">
       <div class="row clearfix" id="tags">
       		<div class="col-xs-12">
       			<div class="panel panel-default" id="comments">
       				<div class="panel-body">
						<h5>
							Les commentaires
							<span class="icon ion-chatbox-working pull-right"></span>
						</h5>
						<p class="lign"></p>
						<ul class="nav nav-tabs" role="tablist">
						    <li role="presentation" class="active"><a href="#all" aria-controls="all" role="tab" data-toggle="tab" id="tab_links">En ligne</a></li>
						    <li role="presentation"><a href="#approved" aria-controls="approved" role="tab" data-toggle="tab" id="tab_links">En attente</a></li>
						    <li role="presentation"><a href="#blocked" aria-controls="blocked" role="tab" data-toggle="tab" id="tab_links">block&eacute;s</a></li>
						</ul>

						<!-- Tab panes -->
						<div class="tab-content">
						    <div role="tabpanel" class="tab-pane active" id="all">
						    	<div class="row comment-row">
					              <div class="col-xs-12 col-sm-12 col-md-12">
					                <div class="row">
					                  <div class="col-xs-9 col-sm-10 col-md-9">
					                    <b>Beni Kabona</b> posted on <b>Lorem ipsum dolor sit amet, consectetur adipisicinguri ...</b><br>
					                    <small>Today 2:21 pm - 01/05/2015</small>
					                  </div>
					                  <div class="col-xs-3 col-sm-2 col-md-3">
					                    <div class="clearfix">
					                      <div class="pull-right comment-difftime">
					                        2 days ago
					                      </div>
					                    </div>
					                  </div>
					                </div>
					                <div class="well well-sm comment-well">
					                  Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni eveniet nam, nulla totam, 
					                  nostrum similique accusantium voluptate ipsa nisi voluptates ab illum odio unde tempora
					                  veritatis mollitia deleniti porro praesentium!
					                </div>
					                <div class="clearfix">
					                  <div class="pull-right">
					                    <a href="" class="btn btn-xs btn-warning" role="button">
					                      <span class="icon ion-reply" aria-hidden="true"></span> 
					                    </a>
					                    <a href="" class="btn btn-xs btn-default" role="button">
					                      <span class="icon ion-ios-minus-outline" aria-hidden="true"></span> 
					                    </a>
					                  </div>
					                </div>
					              </div>
					            </div>
					            <hr>
					            <div class="row comment-row">
					              <div class="col-xs-12 col-sm-12 col-md-12">
					                <div class="row">
					                  <div class="col-xs-9 col-sm-10 col-md-9">
					                    <b>Beni Kabona</b> posted on <b>Lorem ipsum dolor sit amet, consectetur adipisicinguri ...</b><br>
					                    <small>Today 2:21 pm - 01/05/2015</small>
					                  </div>
					                  <div class="col-xs-3 col-sm-2 col-md-3">
					                    <div class="clearfix">
					                      <div class="pull-right comment-difftime">
					                        2 days ago
					                      </div>
					                    </div>
					                  </div>
					                </div>
					                <div class="well well-sm comment-well">
					                  Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni eveniet nam, nulla totam, 
					                  nostrum similique accusantium voluptate ipsa nisi voluptates ab illum odio unde tempora
					                  veritatis mollitia deleniti porro praesentium!
					                </div>
					                <div class="clearfix">
					                  <div class="pull-right">
					                    <a href="" class="btn btn-xs btn-warning" role="button">
					                      <span class="icon ion-reply" aria-hidden="true"></span> 
					                    </a>
					                    <a href="" class="btn btn-xs btn-default" role="button">
					                      <span class="icon ion-ios-minus-outline" aria-hidden="true"></span> 
					                    </a>
					                  </div>
					                </div>
					              </div>
					            </div>
					            <hr>
						    </div>
						    <div role="tabpanel" class="tab-pane" id="approved">
						    	<div class="row comment-row">
					              <div class="col-xs-12 col-sm-12 col-md-12">
					                <div class="row">
					                  <div class="col-xs-9 col-sm-10 col-md-9">
					                    <b>Beni Kabona</b> posted on <b>Lorem ipsum dolor sit amet, consectetur adipisicinguri ...</b><br>
					                    <small>Today 2:21 pm - 01/05/2015</small>
					                  </div>
					                  <div class="col-xs-3 col-sm-2 col-md-3">
					                    <div class="clearfix">
					                      <div class="pull-right comment-difftime">
					                        2 days ago
					                      </div>
					                    </div>
					                  </div>
					                </div>
					                <div class="well well-sm comment-well">
					                  Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni eveniet nam, nulla totam, 
					                  nostrum similique accusantium voluptate ipsa nisi voluptates ab illum odio unde tempora
					                  veritatis mollitia deleniti porro praesentium!
					                </div>
					                <div class="clearfix">
					                  <div class="pull-right">
					                  	<a href="" class="btn btn-xs btn-info" role="button">
					                      <span class="icon ion-android-done-all" aria-hidden="true"></span> 
					                    </a>
					                    <a href="" class="btn btn-xs btn-default" role="button">
					                      <span class="icon ion-ios-minus-outline" aria-hidden="true"></span> 
					                    </a>
					                    <a href="" class="btn btn-xs btn-danger" role="button">
					                      <span class="icon ion-trash-b" aria-hidden="true"></span> 
					                    </a>
					                  </div>
					                </div>
					              </div>
					            </div>
					            <hr>
					            <div class="row comment-row">
					              <div class="col-xs-12 col-sm-12 col-md-12">
					                <div class="row">
					                  <div class="col-xs-9 col-sm-10 col-md-9">
					                    <b>Beni Kabona</b> posted on <b>Lorem ipsum dolor sit amet, consectetur adipisicinguri ...</b><br>
					                    <small>Today 2:21 pm - 01/05/2015</small>
					                  </div>
					                  <div class="col-xs-3 col-sm-2 col-md-3">
					                    <div class="clearfix">
					                      <div class="pull-right comment-difftime">
					                        2 days ago
					                      </div>
					                    </div>
					                  </div>
					                </div>
					                <div class="well well-sm comment-well">
					                  Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni eveniet nam, nulla totam, 
					                  nostrum similique accusantium voluptate ipsa nisi voluptates ab illum odio unde tempora
					                  veritatis mollitia deleniti porro praesentium!
					                </div>
					                <div class="clearfix">
					                  <div class="pull-right">
					                  	<a href="" class="btn btn-xs btn-info" role="button">
					                      <span class="icon ion-android-done-all" aria-hidden="true"></span> 
					                    </a>
					                    <a href="" class="btn btn-xs btn-default" role="button">
					                      <span class="icon ion-ios-minus-outline" aria-hidden="true"></span> 
					                    </a>
					                    <a href="" class="btn btn-xs btn-danger" role="button">
					                      <span class="icon ion-trash-b" aria-hidden="true"></span> 
					                    </a>
					                  </div>
					                </div>
					              </div>
					            </div>
					            <hr>
						    </div>
						    <div role="tabpanel" class="tab-pane" id="blocked">
						    	<div class="row comment-row">
					              <div class="col-xs-12 col-sm-12 col-md-12">
					                <div class="row">
					                  <div class="col-xs-9 col-sm-10 col-md-9">
					                    <b>Beni Kabona</b> posted on <b>Lorem ipsum dolor sit amet, consectetur adipisicinguri ...</b><br>
					                    <small>Today 2:21 pm - 01/05/2015</small>
					                  </div>
					                  <div class="col-xs-3 col-sm-2 col-md-3">
					                    <div class="clearfix">
					                      <div class="pull-right comment-difftime">
					                        2 days ago
					                      </div>
					                    </div>
					                  </div>
					                </div>
					                <div class="well well-sm comment-well">
					                  Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni eveniet nam, nulla totam, 
					                  nostrum similique accusantium voluptate ipsa nisi voluptates ab illum odio unde tempora
					                  veritatis mollitia deleniti porro praesentium!
					                </div>
					                <div class="clearfix">
					                  <div class="pull-right">
					                    <a href="" class="btn btn-xs btn-info" role="button">
					                      <span class="icon ion-android-done-all" aria-hidden="true"></span> 
					                    </a>
					                    <a href="" class="btn btn-xs btn-danger" role="button">
					                      <span class="icon ion-trash-b" aria-hidden="true"></span> 
					                    </a>
					                  </div>
					                </div>
					              </div>
					            </div>
					            <hr>
					            <div class="row comment-row">
					              <div class="col-xs-12 col-sm-12 col-md-12">
					                <div class="row">
					                  <div class="col-xs-9 col-sm-10 col-md-9">
					                    <b>Beni Kabona</b> posted on <b>Lorem ipsum dolor sit amet, consectetur adipisicinguri ...</b><br>
					                    <small>Today 2:21 pm - 01/05/2015</small>
					                  </div>
					                  <div class="col-xs-3 col-sm-2 col-md-3">
					                    <div class="clearfix">
					                      <div class="pull-right comment-difftime">
					                        2 days ago
					                      </div>
					                    </div>
					                  </div>
					                </div>
					                <div class="well well-sm comment-well">
					                  Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni eveniet nam, nulla totam, 
					                  nostrum similique accusantium voluptate ipsa nisi voluptates ab illum odio unde tempora
					                  veritatis mollitia deleniti porro praesentium!
					                </div>
					                <div class="clearfix">
					                  <div class="pull-right">
					                    <a href="" class="btn btn-xs btn-info" role="button">
					                      <span class="icon ion-android-done-all" aria-hidden="true"></span> 
					                    </a>
					                    <a href="" class="btn btn-xs btn-danger" role="button">
					                      <span class="icon ion-trash-b" aria-hidden="true"></span> 
					                    </a>
					                  </div>
					                </div>
					              </div>
					            </div>
					            <hr>
						    </div>
						</div>	
								
       				</div>
       			</div>
       		</div>
       		
       </div>
       <div class="row">
       		<p id="hidden">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi dicta illo ad a, quas numquam, eius perspiciatis amet eos possimus dolor! 
		       	Magnam temporibus dolore ullam consectetur distinctio minus elit. Sequi dicta illo ad a, quas numquam, eius perspiciatis amet eos p
		    </p>
       </div>
       
    </div>
	<!-- End Page Content -->

	@include('admin.includes.bottom-page')
@endsection