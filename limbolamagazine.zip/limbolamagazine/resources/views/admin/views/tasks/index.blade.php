@extends('welcome')

@section('content')
	@include('admin.includes.top-page')
	<!-- nav-side -->
	<div class="col-lg-2 hidden-md hidden-sm hidden-xs display-cell" id="nav-side">
	    <ul>
	        <li class="link">
	            <a href="">
	                <span class="icon ion-ios-keypad"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Home</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="{{ route('view_posts') }}">
	                <span class="icon ion-ios-paper"></span>
	                <span id="text">Articles</span>
	                <small class="label label-default pull-right hidden-md hidden-sm hidden-xs">30</small>
	            </a>
	        </li>
	        @if(Auth::user()->isAdmin())
	        <li class="link">
	            <a href="{{ route('view_users') }}">
	                <span class="icon ion-android-people"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">L'Equipe</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="{{ route('view_visitors') }}">
	                <span class="icon ion-ios-people"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Visiteurs</span>
	                <small class="label label-default pull-right hidden-md hidden-sm hidden-xs">30</small>
	            </a>
	        </li>
	        @endif
	        <li class="link">
	            <a href="{{ route('view_comments') }}">
	                <span class="icon ion-chatbox-working"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Commentaires</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="{{ route('view_tags') }}">
	                <span class="icon ion-link"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Mots cles</span>
	            </a>
	        </li>
	        <li class="link active-link">
	            <a href="{{ route('view_tasks') }}">
	                <span class="icon ion-android-calendar"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Agenda</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="{{ route('profile', ['id' => Auth::user()->id ]) }}">
	                <span class="icon ion-android-contact"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Mon profil</span>
	            </a>
	        </li>
	    </ul>
	</div>
	<!-- End nav-side -->
	@include('admin.includes.nav-header')

	<!-- Page Content -->
	<div class="row clearfix" id="page-content">
       <div class="row clearfix" id="tags">
       		<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
       			<div class="panel panel-default">
       				<div class="panel-body">
						<h5>
							Nouvelle t&acirc;che
							<span class="icon ion-android-calendar pull-right"></span>
						</h5>
						<p class="lign"></p>
						<form class="form-vertical" action="{{ route('post_task') }}" method="Post" role="form">
							<div class="form-group{{ $errors->has('description') ? ' has-error' : '' }}">
								<textarea rows="3" name="description" id="description" class="form-control" placeholder="T&acirc;che" value="{{ Request::old('description') }}"></textarea>
								@if ($errors->has('description'))
						        <span class="help-block">{{ $errors->first('description') }}</span>
						        @endif
							</div>
							<div class="form-group{{ $errors->has('date') ? ' has-error' : '' }}">
								<input type="date" name="date" id="date" class="form-control" placeholder="Date" value="{{ Request::old('date') }}">
								@if ($errors->has('date'))
						        <span class="help-block">{{ $errors->first('date') }}</span>
						        @endif
							</div>
							<div class="form-group{{ $errors->has('time') ? ' has-error' : '' }}">
								<input type="time" name="time" id="time" class="form-control" placeholder="Heure" value="{{ Request::old('time') }}">
								@if ($errors->has('time'))
						        <span class="help-block">{{ $errors->first('time') }}</span>
						        @endif
							</div>
							<div class="checkbox">
							    <label>
							      <input type="checkbox" name="type" value="true"> Urgent
							    </label>
							</div>

							<button class="btn btn-sm btn-default">Soumettre</button>
							<input type="hidden" name="_token" value="{{ Session::token() }}">
						</form>
								
       				</div>
       			</div>
       		</div>
       		<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
       			<div class="panel panel-default" id="tasks">
       				<div class="panel-body">
						<h5>
							Urgents
							<span class="icon ion-alert pull-right"></span>
						</h5>
						<p class="lign"></p>
						@foreach($tasks as $task)
							@if($task->type == 1 && (Auth::user()->id === $task->user_id))
							<div class="col-xs-9 text-left">
								<span id="description">{{ $task->description }}</span>
								<br>
								<span>Pour le {{$task->date}}&nbsp;</span>
								@if($task->time !== '00:00:00')
									<span> &acirc; &nbsp;{{$task->time}}</span>
								@endif
								<hr>
							</div>
							<div class="col-xs-3 text-right">
								<a href="">
									<span class="icon ion-edit"></span>
								</a>
								<a href="">
									<span class="icon ion-clipboard"></span>
								</a>
								<a href="">
									<span class="icon ion-trash-b"></span>
								</a>
								<br>
								<span class="label label-danger">Urgent</span>
							</div>
							
							@endif
						@endforeach		
       				</div>
       			</div>
       		</div>
       		<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
       			<div class="panel panel-default" id="tasks">
       				<div class="panel-body">
						<h5>
							Secondaires
							<span class="icon ion-clipboard pull-right"></span>
						</h5>
						<p class="lign"></p>
						@foreach($tasks as $task)
							@if($task->type == 0 && (Auth::user()->id === $task->user_id))
							<div class="col-xs-9 text-left">
								<span id="description">{{ $task->description }}</span>
								<br>
								<span>Pour le {{$task->date}}&nbsp;</span>
								@if($task->time !== '00:00:00')
									<span> &acirc; &nbsp;{{$task->time}}</span>
								@endif
								<hr>
							</div>
							<div class="col-xs-3 text-right">
								<a href="">
									<span class="icon ion-edit"></span>
								</a>
								<a href="">
									<span class="icon ion-alert"></span>
								</a>
								<a href="">
									<span class="icon ion-trash-b"></span>
								</a>
								<br>
								<span class="label label-default">Secondaire</span>
							</div>
							
							@endif
						@endforeach				
       				</div>
       			</div>
       		</div>
       		
       </div>
       <div class="row">
       		<p id="hidden">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi dicta illo ad a, quas numquam, eius perspiciatis amet eos possimus dolor! 
		       	Magnam temporibus dolore ullam consectetur distinctio minus elit. Sequi dicta illo ad a, quas numquam, eius perspiciatis amet eos p
		    </p>
       </div>
       
    </div>
	<!-- End Page Content -->

	@include('admin.includes.bottom-page')
@endsection