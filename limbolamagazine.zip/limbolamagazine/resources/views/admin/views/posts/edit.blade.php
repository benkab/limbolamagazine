@extends('welcome')

@section('content')
	@include('admin.includes.top-page')
	<!-- nav-side -->
	<div class="col-lg-2 hidden-md hidden-sm hidden-xs display-cell" id="nav-side">
	    <ul>
	        <li class="link">
	            <a href="">
	                <span class="icon ion-ios-keypad"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Home</span>
	            </a>
	        </li>
	        <li class="link active-link">
	            <a href="{{ route('view_posts') }}">
	                <span class="icon ion-ios-paper"></span>
	                <span id="text">Articles</span>
	                <small class="label label-default pull-right hidden-md hidden-sm hidden-xs">30</small>
	            </a>
	        </li>
	        @if(Auth::user()->isAdmin())
	        <li class="link">
	            <a href="{{ route('view_users') }}">
	                <span class="icon ion-android-people"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">L'Equipe</span>
	            </a>
	        </li>
	        
	       <li class="link">
	            <a href="{{ route('view_visitors') }}">
	                <span class="icon ion-ios-people"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Visiteurs</span>
	                <small class="label label-default pull-right hidden-md hidden-sm hidden-xs">30</small>
	            </a>
	        </li>
	        @endif
	        <li class="link">
	            <a href="">
	                <span class="icon ion-chatbox-working"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Commentaires</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="{{ route('view_tags') }}">
	                <span class="icon ion-link"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Mots cles</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="{{ route('view_tasks') }}">
	                <span class="icon ion-android-calendar"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Agenda</span>
	            </a>
	        </li>
	        <li class="link">
	            <a href="{{ route('profile', ['id' => Auth::user()->id ]) }}">
	                <span class="icon ion-android-contact"></span>
	                <span id="text" class="hidden-md hidden-sm hidden-xs">Mon profil</span>
	            </a>
	        </li>
	    </ul>
	</div>
	<!-- End nav-side -->
	@include('admin.includes.nav-header')

	<!-- Page Content -->
	<div class="row clearfix" id="page-content">
       <div class="row clearfix" id="tags">
       		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
       			<div class="panel panel-default">
       				<div class="panel-body" id="posts">
						<h5>
							Editer l'article
							<div class="pull-right">
								<a href="{{ route('view_posts') }}" id="back"><span class="icon ion-ios-undo"></span></a>
								<span class="icon ion-edit"></span>
							</div>
						</h5>
						<p class="lign"></p>
						<div class="row">
							<div class="col-xs-12">
								<form class="form-vertical" action="{{ route('post_edit_post', ['id' => $post->id]) }}" method="Post" role="form" enctype="multipart/form-data">
									<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 thumbnail">
										<img src="{{ URL::to('../public/uploads/posts/').'/'.$post->cover }}" alt="post-image" id="post-image">
									</div>
									<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
										<div id="view-category">
											<div id="view-category-inner">
												<span>{{ $post->categories->description }}</span>
											</div>
										</div>
										<div class="form-group{{ $errors->has('cover') ? ' has-error' : '' }}">
											<span for="cover" class="control-label" id="label">Changez de photo de couverture</span>
											<br>
											<input type="file" name="cover" id="cover" class="form-control" accept=".png, .jpg">
											@if ($errors->has('cover'))
									        <span class="help-block">{{ $errors->first('cover') }}</span>
									        @endif
										</div>
									</div>
									<div class="form-group{{ $errors->has('title') ? ' has-error' : '' }}">
										<textarea name="title" id="title" rows="3" class="form-control" placeholder="Nouveau titre de l'article">{{ Request::old('title') ?: $post->title}}</textarea>
										@if ($errors->has('title'))
								        <span class="help-block">{{ $errors->first('title') }}</span>
								        @endif
									</div>
									<div class="form-group{{ $errors->has('tags') ? ' has-error' : '' }}">
								  		<select multiple="true" id="tag" name="tags[]" class="form-control" >
								  			@foreach($tags as $tag)
											<option value="{{ $tag->id }}">{{$tag->description}}</option>
											@endforeach
										</select>
										@if ($errors->has('tags'))
								            <span class="help-block">{{ $errors->first('tags') }}</span>
								        @endif
								  	</div>
								  	<ul id="post-tags" class="post-tags">
										@foreach( $post->tags->lists('description') as $tag)
										<li>{{ $tag }}</li>
										@endforeach
									</ul>
									<!-- <div class="form-group{{ $errors->has('category') ? ' has-error' : '' }}">
								  		<select name="category" class="form-control" id="category">
								  			<option value="" disabled selected>Categorie</option>
								  			@foreach($categories as $category)
											<option value="{{$category->id}}">{{$category->description}}</option>
											@endforeach
										</select>
										@if ($errors->has('category'))
								            <span class="help-block">{{ $errors->first('category') }}</span>
								        @endif
								  	</div> -->
								  	<div class="form-group{{ $errors->has('body') ? ' has-error' : '' }}">
								  		<textarea id="editable" name="body" rows="15" class="form-control">{{ Request::old('body') ?: $post->body}}</textarea>
								  		@if ($errors->has('body'))
								            <span class="help-block">{{ $errors->first('body') }}</span>
								        @endif
								    </div>
									<button class="btn btn-sm btn-default">Soumettre</button>
									<input type="hidden" name="_token" value="{{ Session::token() }}">
								</form>
							</div>
						</div>
       				</div>
       			</div>
       		</div>
       </div>
       <div class="row">
       		<p id="hidden">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi dicta illo ad a, quas numquam, eius perspiciatis amet eos possimus dolor! 
		       	Magnam temporibus dolore ullam consectetur distinctio minus elit. Sequi dicta illo ad a, quas numquam, eius perspiciatis amet eos p
		      
		    </p>
       </div>
    </div>
	<!-- End Page Content -->

	@include('admin.includes.bottom-page')
@endsection