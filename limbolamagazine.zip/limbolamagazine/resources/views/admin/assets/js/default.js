$(document).ready(function(){
	$('#nav-toggle').click(function(e){

		e.preventDefault();
		$('#nav-side').toggleClass('animation');
		$('#nav-side').toggleClass('hidden-xs');
		$('#nav-side').toggleClass('hidden-md');
		$('#nav-side').toggleClass('hidden-sm');
		$('#logo').toggleClass('hidden');
		$('#nav-toggle').toggleClass('maitain-position');
		$('#nav-side ul li').toggleClass('resize');
		
	});

	
	$('#role').chosen();

	$('#tag').chosen();

	$('#editable').froalaEditor({
		height: 300,
		fontSizeDefaultSelection: '13'
	});





});