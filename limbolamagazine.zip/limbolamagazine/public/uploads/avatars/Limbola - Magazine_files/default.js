$(document).ready(function(){
	$('#tag').chosen();

	$('#editable').summernote({ 
		height: 300,
		fontsize: 14,
		toolbar: [
		    // [groupName, [list of button]]
		    ['style', ['bold', 'italic', 'underline', 'clear']],
		    ['font', ['strikethrough', 'superscript', 'subscript']],
		    ['fontsize', ['fontsize']],
		    ['color', ['color']],
		    ['para', ['ul', 'ol', 'paragraph']],
		    ['height', ['height']]
		  ]
	});
	$('#editable').summernote('fontSize', 14);
	$('#editable').summernote('fontName', 'Muli', 'sans-serif');


	$('#nav-toggle').click(function(e){

		e.preventDefault();
		$('#nav-side').toggleClass('animation');
		$('#nav-side').toggleClass('hidden-xs');
		$('#nav-side').toggleClass('hidden-md');
		$('#nav-side').toggleClass('hidden-sm');
		$('#logo').toggleClass('hidden');
		$('#nav-toggle').toggleClass('maitain-position');
		$('#nav-side ul li').toggleClass('resize');
		
	});


});